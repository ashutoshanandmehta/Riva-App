# Architecture Graph

> Regenerate with /graph.

```
Frontend -> API Gateway -> Auth Service -> User Service -> Database -> Redis
```
