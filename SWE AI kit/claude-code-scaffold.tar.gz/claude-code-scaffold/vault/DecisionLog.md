# Decision Log

> Append-only. One entry per architectural decision.

## Use PostgreSQL
- Reason: ACID compliance
- Date: 2026-07-23
- Owner: Architecture Agent
