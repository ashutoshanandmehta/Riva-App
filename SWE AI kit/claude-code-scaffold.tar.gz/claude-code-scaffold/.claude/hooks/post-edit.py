#!/usr/bin/env python3
"""PostToolUse(Edit|Write): format, lint, warn. Cannot undo the write — advisory only."""
import json, os, subprocess, sys

data = json.load(sys.stdin)
path = ((data.get("tool_input") or {}).get("file_path")) or ""
if not path or not os.path.exists(path):
    sys.exit(0)

def run(cmd):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None

notes = []
if path.endswith((".ts", ".tsx", ".js", ".jsx", ".json", ".css", ".md")):
    run(["npx", "--no-install", "prettier", "--write", path])
    r = run(["npx", "--no-install", "eslint", path])
    if r and r.returncode != 0:
        notes.append(r.stdout[-1500:])
elif path.endswith(".py"):
    run(["ruff", "format", path])
    r = run(["ruff", "check", path])
    if r and r.returncode != 0:
        notes.append(r.stdout[-1500:])

with open(path) as fh:
    lines = fh.read().splitlines()
if len(lines) > 500:
    notes.append(f"{os.path.basename(path)} is {len(lines)} lines (soft limit 500). "
                 f"Split before it reaches the 1000-line hard limit.")

src = "/".join(path.split("/")[-3:])
if "/app/" in path and not any(t in path for t in ("test", "spec")):
    notes.append(f"Reminder: {os.path.basename(path)} needs tests before this change can pass the verifier.")

if notes:
    print("Post-edit findings:\n" + "\n".join(notes), file=sys.stderr)
    sys.exit(1)   # surfaced to Claude, does not block
sys.exit(0)
