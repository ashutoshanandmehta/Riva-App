#!/usr/bin/env python3
"""Stop: refuse to end the turn on unverified changes. Exit 2 forces Claude to keep working."""
import json, os, sys

data = json.load(sys.stdin)
root = os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd())

if data.get("stop_hook_active"):
    sys.exit(0)   # already looping; do not trap

dirty = os.path.join(root, ".claude/state/dirty.flag")
verified = os.path.join(root, ".claude/state/verified.flag")

if os.path.exists(dirty) and not os.path.exists(verified):
    print("Code was modified but the verifier has not passed. "
          "Run the `verifier` subagent on the change set and report the confidence score "
          "before finishing.", file=sys.stderr)
    sys.exit(2)

for f in (dirty, verified):
    try:
        os.remove(f)
    except FileNotFoundError:
        pass
sys.exit(0)
