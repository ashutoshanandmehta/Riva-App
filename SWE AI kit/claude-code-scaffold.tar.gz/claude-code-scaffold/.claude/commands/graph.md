---
description: Regenerate the architecture dependency graph
---
Trace imports across app/ and rewrite vault/ArchitectureGraph.md as a dependency graph.
Flag any cycle and any edge that crosses a layer boundary defined in vault/Architecture.md.
